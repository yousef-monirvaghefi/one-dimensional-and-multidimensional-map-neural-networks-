# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 18:30:56 2024

@author: Yousef
"""

import numpy as np

inputdimension = 3 # Number of Input Dimensions
LR = 0.0001 #Learning Rate
centersnumber = 24 # Number of Clusters 

hidden_weights = np.random.rand(centersnumber, inputdimension, inputdimension, 3)

output_weights = np.random.rand(centersnumber, inputdimension, inputdimension)

def sigmoid(x):
     return 1/(1 + np.exp(-x))
 
def compute_output(X, choice):
   
    Features = np.zeros((inputdimension,inputdimension))
    
    for i in range(inputdimension):
        for j in range(inputdimension):
            Features[i,j] = hidden_weights[choice,i,j,0] * X[i] \
            + hidden_weights[choice,i,j,1] * X[j] + \
            hidden_weights[choice,i,j,2]
            Features[i,j] = sigmoid(Features[i,j])
            Features[i,j] = output_weights[choice,i,j] * Features[i,j]
    
    networkout= np.sum(Features)
    
    return networkout

def backpropagation(inputnumber):
    
    choice = cluster_indx[inputnumber]
    
    # error for inputnumber data
    error = outputdata[inputnumber] - compute_output(inputdata[inputnumber], choice)
        
    Features = np.zeros((inputdimension,inputdimension))
    
    for i in range(inputdimension):
        for j in range(inputdimension):
            Features[i,j] = hidden_weights[choice,i,j,0] * \
            inputdata[inputnumber,i] + hidden_weights[choice,i,j,1]\
            * inputdata[inputnumber,j] + hidden_weights[choice,i,j,2]
            Features[i,j] = sigmoid(Features[i,j])
            
    for i in range(inputdimension):
        for j in range(inputdimension):
            output_weights[choice,i,j] += LR * error * Features[i,j]
    
    for i in range(inputdimension):
        for j in range(inputdimension):
            hidden_weights[choice,i,j,0] += LR * error * \
            output_weights[choice,i,j] * Features[i,j] * \
            (1-Features[i,j]) * inputdata[inputnumber,i]
            
            hidden_weights[choice,i,j,1] += LR * error * \
            output_weights[choice,i,j] * Features[i,j] * \
            (1-Features[i,j]) * inputdata[inputnumber,j]
            
            hidden_weights[choice,i,j,2] += LR * error * \
            output_weights[choice,i,j] * Features[i,j] * \
            (1-Features[i,j])
    
