# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 12:05:31 2024

@author: Yousef
"""
import numpy as np

inputdimension = 3 # Number of Input Dimensions
LR = 0.0001 #Learning Rate
centersnumber = 24 # Number of Clusters 

hidden_weights = np.random.rand(centersnumber, inputdimension, inputdimension, inputdimension, 4)

output_weights = np.random.rand(centersnumber, inputdimension, inputdimension, inputdimension)

def sigmoid(x):
     return 1/(1 + np.exp(-x))

def compute_output(input1, choice):

    Features = np.zeros((inputdimension,inputdimension,inputdimension))
    
    for k in range(inputdimension):
        for i in range(inputdimension):
            for j in range(inputdimension):
                Features[k,i,j] = hidden_weights[choice,k,i,j,0] * input1[i] \
                + hidden_weights[choice,k,i,j, 1] * input1[j] + \
                + hidden_weights[choice,k,i,j, 2] * input1[k] + \
                hidden_weights[choice,k,i,j, 3]
                Features[k,i,j] = sigmoid(Features[k,i,j])
                Features[k,i,j] = output_weights[choice,k,i,j] * Features[k,i,j]
        
    networkout= np.sum(Features)
    
    return networkout 

def backpropagation(inputnumber):
    
    choice = cluster_indx[inputnumber]
    
    # error for inputnumber data
    error = outputdata[inputnumber] - compute_output(inputdata[inputnumber], choice)
    
    Features = np.zeros((inputdimension,inputdimension,inputdimension))
    
    for k in range(inputdimension):
        for i in range(inputdimension):
            for j in range(inputdimension):
                Features[k,i,j] = hidden_weights[choice,k,i,j,0] * \
                inputdata[inputnumber,i] + hidden_weights[choice,k,i,j,1]\
                * inputdata[inputnumber,j] + hidden_weights[choice,k,i,j,2]\
                * inputdata[inputnumber,k]+ hidden_weights[choice,k,i,j,3]
                Features[k,i,j] = sigmoid(Features[k,i,j])
            
    for k in range(inputdimension):
        for i in range(inputdimension):
            for j in range(inputdimension):
                output_weights[choice,k,i,j] += LR * error * Features[k,i,j]
     
    for k in range(inputdimension):    
        for i in range(inputdimension):
            for j in range(inputdimension):
                hidden_weights[choice,k,i,j,0] += LR * error * \
                output_weights[choice,k,i,j] * Features[k,i,j] * \
                (1-Features[k,i,j]) * inputdata[inputnumber,i]
                
                hidden_weights[choice,k,i,j,1] += LR * error * \
                output_weights[choice,k,i,j] * Features[k,i,j] * \
                (1-Features[k,i,j]) * inputdata[inputnumber,j]
                
                hidden_weights[choice,k,i,j,2] += LR * error * \
                output_weights[choice,k,i,j] * Features[k,i,j] * \
                (1-Features[k,i,j]) * inputdata[inputnumber,k]
                
                hidden_weights[choice,k,i,j,3] += LR * error * \
                output_weights[choice,k,i,j] * Features[k,i,j] * \
                (1-Features[k,i,j])
    
