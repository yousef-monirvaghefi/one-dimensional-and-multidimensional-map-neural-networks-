# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 17:49:01 2024

@author: Yousef
"""

import numpy as np

inputdimension = 3 # Number of Input Dimensions
LR = 0.0001 #Learning Rate
centersnumber = 24 # Number of Clusters

hidden_weights = np.random.rand(centersnumber, inputdimension, inputdimension, inputdimension, 4)

output_weights = np.random.rand(centersnumber, inputdimension, inputdimension, inputdimension)

def sigmoid(x):
     return 1/(1 + np.exp(-x))

def compute_output2(X, choice):
    
    Features = np.zeros((inputdimension,inputdimension,inputdimension))
    
    dim = X.shape[0]
    X = np.tile(X, dim)
    X = np.reshape(X, (dim, dim))
    X = np.tile(X, (1, dim))
    X = np.reshape(X, (dim,dim,dim))
    X1 = X
    X2 = np.transpose(X,axes=[2, 0, 1])
    X3 = np.transpose(X,axes=[1, 2, 0])
    
    Features[:,:,:] = hidden_weights[choice,:,:,:,0] * X1 + \
                      hidden_weights[choice,:,:,:,1] * X2 + \
                      hidden_weights[choice,:,:,:,2] * X3 + \
                      hidden_weights[choice,:,:,:,3]
    
    Features[:,:,:] = sigmoid(Features[:,:,:])
    Features[:,:,:] = output_weights[choice,:,:,:] * Features[:,:,:]
    
    networkout= np.sum(Features)
    return networkout

def backpropagation2(inputnumber):
    
    choice = cluster_indx[inputnumber]
    
    # error for inputnumber data
    error = outputdata[inputnumber] - compute_output2(inputdata[inputnumber], choice)
    
    Features = np.zeros((inputdimension,inputdimension,inputdimension))
    
    X = inputdata[inputnumber]
    dim = X.shape[0]
    X = np.tile(X, dim)
    X = np.reshape(X, (dim, dim))
    X = np.tile(X, (1, dim))
    X = np.reshape(X, (dim,dim,dim))
    X1 = X
    X2 = np.transpose(X,axes=[2, 0, 1])
    X3 = np.transpose(X,axes=[1, 2, 0])
    
    Features[:,:,:] = hidden_weights[choice,:,:,:,0] * X1 + \
                      hidden_weights[choice,:,:,:,1] * X2 + \
                      hidden_weights[choice,:,:,:,2] * X3 + \
                      hidden_weights[choice,:,:,:,3]
    
    Features[:,:,:] = sigmoid(Features[:,:,:])
                    
    output_weights[choice,:,:,:] += LR * error * Features[:,:,:]
    
    hidden_weights[choice,:,:,:,0] += LR * error * \
    output_weights[choice,:,:,:] * Features[:,:,:] * \
    (1-Features[:,:,:]) * X1
    
    hidden_weights[choice,:,:,:,1] += LR * error * \
    output_weights[choice,:,:,:] * Features[:,:,:] * \
    (1-Features[:,:,:]) * X2
    
    hidden_weights[choice,:,:,:,2] += LR * error * \
    output_weights[choice,:,:,:] * Features[:,:,:] * \
    (1-Features[:,:,:]) * X3
    
    hidden_weights[choice,:,:,:,3] += LR * error * \
    output_weights[choice,:,:,:] * Features[:,:,:] * (1-Features[:,:,:])

