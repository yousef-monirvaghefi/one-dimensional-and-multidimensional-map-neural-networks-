# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 10:17:14 2024

@author: Yousef
"""
import numpy as np

inputdimension = 3 # 
LR = 0.0001 #Learning Rate
centersnumber = 24
          
first_layer_weights = np.random.rand(centersnumber, inputdimension, 2)

second_layer_weights = np.random.rand(centersnumber, inputdimension)

def compute_output(X, choice):   
        
    linear = first_layer_weights[choice,:,0]*X + first_layer_weights[choice,:,1]
    first_layer_neurons = np.abs(np.sin(np.deg2rad(linear[:])))   
       
    networkout = second_layer_weights[choice,:]*first_layer_neurons[:]
    
    networkout = networkout.sum()
            
    return networkout

def backpropagation(inputnumber):
    
    choice = cluster_indx[inputnumber]
    
    # error for inputnumber data
    error = outputdata[inputnumber] - compute_output(inputdata[inputnumber], choice)

    linear = first_layer_weights[choice,:,0]*inputdata[inputnumber,:] + first_layer_weights[choice,:,1]
    second_layer_weights[choice,:]+=LR * error * \
    np.abs(np.sin(np.deg2rad(linear)))
    
    # update first layer weight 0
    first_layer_weights[choice,:,0] += \
    LR * error * second_layer_weights[choice,:] * \
    np.cos(np.deg2rad(linear))*np.sin(np.deg2rad(linear))/ \
    np.abs(np.sin(np.deg2rad(linear)))* inputdata[inputnumber]
   
    # update first layer weight 1
    first_layer_weights[choice,:, 1] += \
    LR * error * second_layer_weights[choice,:] *\
    np.cos(np.deg2rad(linear))*np.sin(np.deg2rad(linear))/ \
    np.abs(np.sin(np.deg2rad(linear)))

